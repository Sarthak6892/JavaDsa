package com.lpu.dsa.java;
public class AdvancedPatterPrinting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Printing Advanced Pattern!");
		System.out.println();
		pattern5();
	}
	
	static void pattern1() {
		// Butterfly Pattern
		System.out.println("Butterfly Patter!");
		int row = 4;
		for(int i = 1; i <= row; i++) {
			
			for(int j = 1; j <= i; j++) {
				System.out.print("*");
			}
			
			for(int k = 1; k <= (2 * (row-i)) ; k++) {
				System.out.print(" ");
			}
			
			for (int j = 1; j <= i; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		// Printing Upper half
		
		for(int i = row; i > 0; i--) {
			
			for(int j = i; j > 0 ; j--) {
				System.out.print("*");
			}
			
			for(int k = 1; k <= (2 * (row-i)) ; k++) {
				System.out.print(" ");
			}
			
//			for (int j = 1; j <= i; j++) {
//				System.out.print("*");
//			}
			for(int j = i; j > 0 ; j--) {
				System.out.print("*");
			}
			System.out.println();
		}
		//printing lower half
	}
	
	static void pattern2() {
		// Solid Rombous
		System.out.println("Solid Rombus!");
		int row = 5;
		for (int i = 1; i <= row; i++) {
			for(int j = 1; j <= (row-i); j++) {
				System.out.print(" ");
			}
			for (int j = 1; j <= row; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		
	}
	
	static void pattern3() {
		// Pyramid
		int row = 5;
		System.out.println("Pyramid!");
		for (int i = 0; i < row ; i++) {
			for (int j = 0 ; j < (row-i-1) ; j++) {
				System.out.print(" ");
			}
			for ( int j = 0; j < (2*i + 1) ; j++) {
				System.out.print("*");
			}
//			for ( int j = 0; j < (row-i-1); j++) {
//				System.out.print(" ");
//			}
			System.out.println();
		}
	}
	
	static void pattern4() {	
		// Inverted Pyramid
		int row = 5;
		System.out.println("Inverted Pyramid!");
		for(int i = 0; i < row; i++) {
			for ( int j = 0; j < i; j++) {
				System.out.print(" ");
			}
			for (int j = 0; j < (2 * (row - i- 1)+1); j++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
	
	static void pattern5() {
		int row = 5;
		System.out.println("Pattern!");
		for (int i = 0; i < row ; i++) {
			for (int j = 0 ; j < (row-i-1) ; j++) {
				System.out.print(" ");
			}
			for ( int j = 0; j < (2*i + 1) ; j++) {
				System.out.print("*");
			}
			
			System.out.println();
		}
		for(int i = 0; i < row; i++) {
			for ( int j = 0; j < i; j++) {
				System.out.print(" ");
			}
			for (int j = 0; j < (2 * (row - i- 1)+1); j++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
	

}
