package com.lpu.dsa.java;

public class Methods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		employe("John",980000.0F,"Developer");
		System.out.println("Average of three number ::"+func2(1,2,3));
		Methods obj = new Methods();
		obj.func3();
	}
	
	 static void employe(String name,float salary, String designation) {
		func2(1,2,3);
		System.out.println("Name of Employee:: " + name);
		System.out.println("Salary:: "+salary);
		System.out.println("Designation:: "+designation);
	}

	 static float func2(int a, int b, int c) {
		
		return ((a+b+c)/3);
	}
	 
	 void func3() {
		 System.out.println("Non static function!");
	 }
	
}
