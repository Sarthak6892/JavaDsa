package com.lpu.dsa.java;
import java.util.*;

public class TakingInput {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		String UserName;
		int UserAge;
		String UserCity;
		
		UserName = sc.next();
		UserAge = sc.nextInt();
		UserCity = sc.next();
		
		System.out.println("User Name:"+UserName);
		System.out.println("User Age:" + UserAge);
		System.out.println("User City: "+UserCity);
		
		sc.close();
	}

}
