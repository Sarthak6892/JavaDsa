package com.lpu.dsa.java;

public class SwitchCase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char operator = '%';
		switch(operator) {
		
		case '+': System.out.println("add");
		break;
		
		case '-': System.out.println("Sub");
		break;
		
		case '*': System.out.println("Multi");
		break;
		
		case '/': System.out.println("Divide");
		break;
		
		case '%': System.out.println("");
		break;
		
		}
	}

}
