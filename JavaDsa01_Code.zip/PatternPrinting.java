package com.lpu.dsa.java;
import java.util.Scanner;

public class PatternPrinting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Printing Patter!");
		
		System.out.println();
		
		Scanner sc = new Scanner(System.in);
		
		pattern9();
		sc.close();
		}
	
	 static void solidRectangle(Scanner sc) {
		 
		int row, col;
		row = sc.nextInt();
		col = sc.nextInt();
		// Taking Row and Coloumn value input from user
		
		System.out.println("Solid Rectangle!");
		for(int i = 1; i <= row; i++) {
			for(int j = 1; j <= col; j++) {
				System.out.print("*");
			}
			System.out.println(" ");
		}
		// Logic For the Pattern
	}
	 
	static void hollowRectangle(Scanner sc) {
		System.out.println("Hollow Rectangle!");
		
		int row, col;
		row = sc.nextInt();
		col = sc.nextInt();
		// Taking row and column value input
		
		for(int i = 1; i <= row; i++) {
			for(int j = 1; j <= col; j++) {
				if(i == 1 || j == 1 || i == row || j == col) {
					System.out.print("*");
				}
				else {
					System.out.print(" ");
				}
			}
			System.out.println();
		}
		
	}
	
	static void halfPyramid(Scanner sc) {
		int row;
		System.out.println("Enter rows!");
		row = sc.nextInt();
		
		for ( int i = 1; i <= row; i++) {
			for (int j = 1; j <= i ; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
	
	static void invertedHalfPyramid(Scanner sc) {
		int row;
		System.out.println("Enter rows!");
		row = sc.nextInt();
		
//		for ( int i = row; i > 0; i--) {
//			for (int j = i; j > 0 ; j--) {
//				System.out.print("*");
//			}
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < (row - i); j++) {
				System.out.print("+");
			}
			System.out.println();
		}
	}
	
	static void pattern5() {
		// Inverted Half Pyramid rotated by 180 degree
		
		int row = 4;
		
		for(int i = 1; i <= row; i++) {
			for( int k = 1; k <= row-i; k++) {
				System.out.print(" ");
			}
			for(int j = 1; j <= i; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		
	}
	
	static void pattern6() {
		// half pyramid with number
		int row = 5;
		for(int i = 1; i <= row; i++) {
			for(int j = 1 ; j <= i; j++) {
				System.out.print(j);
			}
			System.out.println();
		}
		
	}
	
	static void pattern7() {
		// Inverted half Pyramid with numbers
		int row = 5;
		for(int i = 1; i <= row; i++) {
			for(int j = 1 ; j <= row-i+1; j++) {
				System.out.print(j);
			}
			System.out.println();
		}
		// using (n-i+1) will take minimum time to solve this question.
	}
	
	static void pattern8() {
		// Floyd's Triangle
		int count = 1;
		for(int i = 1 ; i <= 5; i++) {
			for(int j = 1; j <= i; j++) {
				System.out.print(count+" ");
				count++;
			}
			System.out.println();
		}
	}
	
	static void pattern9() {
		// 0-1 triangle
		
		for(int i = 1; i <= 5; i++) {
			for(int j = 1; j <= i; j++) {
				if ((i+j) % 2 == 0) {
					System.out.print("1 ");
				}
				else {
					System.out.print("0 ");
				}
			}
			System.out.println();
		}
		
	}
	
}


