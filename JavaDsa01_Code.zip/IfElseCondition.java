package com.lpu.dsa.java;
import java.util.*;

public class IfElseCondition {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int age;
		String nationality = "Indian";
		
		System.out.print("Enter Age:: "); age = sc.nextInt();
//		System.out.println("Enter Nationality :: "); nationality = sc.nextLine();
		
		if( age > 0 && age > 18 && age <= 100 && nationality == "Indian") {
			System.out.println("Can Vote!");
		}
		else {
			System.out.println("Cannot Vote!");
		}
		sc.close();
	}

}
