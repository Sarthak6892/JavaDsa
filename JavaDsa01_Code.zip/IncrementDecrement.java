package com.lpu.dsa.java;

public class IncrementDecrement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1 = 5;
		int num2 = 5;
		num1++;
		System.out.println(num1);
//		System.out.println(num1++ + ++num2);
		System.out.println(num1 != num2);
	}
}
